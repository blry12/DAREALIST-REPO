'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/darealist2021/DAREALIST-BUILDS/refs/heads/main/Darealistbuildsnew.xml'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notification File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/darealist2021/DAREALIST-BUILDS/refs/heads/main/darealistnotify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'http://CHANGEME/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
