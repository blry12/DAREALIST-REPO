# plugin.program.simplewizard
Simple Wizard for Kodi
